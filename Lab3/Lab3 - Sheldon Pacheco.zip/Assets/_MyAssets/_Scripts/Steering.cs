using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Steering
{
    public static Vector3 Seek(Vector3 seekerPosition, Vector3 seekerVelocity, float movespeed)
    {
        return (seekerPosition);
    }
}
